import { t } from "i18next"

function Profile() {
  return (
    <div className="container">
      <h2>{t('Profile')}</h2>
    </div>
  )
}

export default Profile