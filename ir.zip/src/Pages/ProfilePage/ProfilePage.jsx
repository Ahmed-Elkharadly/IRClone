import { t } from "i18next"

function ProfilePage() {
  return (
    <div className="container">
      <h2>{t('ProfilePage')}</h2>
    </div>
  )
}

export default ProfilePage