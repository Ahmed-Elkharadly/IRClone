import i18next, { t } from "i18next";
import "./filterbar.scss";
import { useState } from "react";
import { CustomProvider, DateRangePicker } from "rsuite";
import arEG from 'rsuite/locales/ar_EG';
import enUS from 'rsuite/locales/en_US';

function FilterBar({ data, setData, setCurrentItems }) {
    const [dateRange, setDateRange] = useState();
    const [filterObj, setFilterObj] = useState({
        startDate: '',
        endDate: '',
        name: '',
        value: ''
    })

    const handleDateChange = (value) => {
        setDateRange(value);
        setFilterObj({
            ...filterObj,
            startDate: new Date(value[0]?.toISOString().split('T')[0]),
            endDate: new Date(value[1].toISOString().split('T')[0])
        })
    };
    const hanldeChange = (e) => {
        const { value, name } = e.target
        setFilterObj({
            ...filterObj,
            [name]: value
        })
    }
    const handleFilteration = () => {
        const filterData = () => {
            let { name, value, startDate, endDate } = filterObj
            let filteredData = data;

            if (startDate && endDate) { filteredData = filterByDateRange(filteredData, startDate, endDate); }
            if (name) { filteredData = filterByName(filteredData, name); }
            if (value) { filteredData = filterByValue(filteredData, value); }
            return filteredData;
        };
        // setData(filterData())
        setCurrentItems(filterData())
    };

    const filterByDateRange = (filteredData, startDate, endDate) => {
        return filteredData?.filter(obj => new Date(obj?.date) >= startDate && new Date(obj?.date) <= endDate);
    }
    const filterByName = (filteredData, name) => {
        return filteredData?.filter(obj => obj?.name.includes(name));
    }
    const filterByValue = (filteredData, value) => {
        return filteredData?.filter(obj => Number(obj?.value) === Number(value));
    }

    return (
        <div className=" border my-3 p-3 filterBar rounded bg-light">
            <div className="row p-0 d-flex flex-wrap align-items-center justify-content-between">
                <div className="col-lg-4 col-12 my-2 d-flex flex-column">
                    <label className="col-lg-2 w-75 mb-2 d-flex justify-content-between" htmlFor="date"> {t("Date")}: <span>X</span></label>
                    <CustomProvider locale={i18next?.language === "ar" ? arEG : enUS}>
                        <DateRangePicker value={dateRange} onChange={handleDateChange} cleanable={false} className="flex-grow-1 mx-2" />
                    </CustomProvider>
                </div>

                <div className="col-lg-4 col-12 my-2 d-flex flex-column">
                    <label className="col-lg-2 mb-2" htmlFor="name">{t('Name')}:</label>
                    <input name="name" value={filterObj?.name} onChange={(e) => hanldeChange(e)} className="rounded p-2 bg-white border text-primary flex-grow-1 mx-2" placeholder={t("search by name")} id='name' type="text" />
                </div>

                <div className="col-lg-4 col-12 my-2 d-flex flex-column">
                    <label className="col-lg-2 mb-2" htmlFor="value">{t('Value')}:</label>
                    <input name="value" value={filterObj?.value} onChange={(e) => hanldeChange(e)} className="rounded p-2 bg-white border text-primary flex-grow-1 mx-2" placeholder={t("search by value")} id='value' type="number" />
                </div>

            </div>
            <div className="d-flex flex-wrap justify-content-lg-between justify-content-center ">
                <button
                    className="col-lg-2 col-12 my-2 btn btn-outline-dark "
                    onClick={handleFilteration}
                // disabled={!filterObj.name && !filterObj.startDate && !filterObj.value}
                >
                    {t("Search")}
                </button>
                <div className="col-lg-2 d-flex justify-content-end">
                    <h2 className="bi bi-file-pdf"></h2>
                    <h2 className="bi bi-file-earmark-text"></h2>
                    <h2 className="bi bi-printer"></h2>
                </div>
            </div>
        </div>
    );
}

export default FilterBar;
